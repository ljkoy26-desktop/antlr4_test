select a, b,
a d,
ddd as ddd,
ddd as "dfdf",
x as
from dual


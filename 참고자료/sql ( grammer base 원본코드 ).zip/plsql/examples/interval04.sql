select interval'20' day - interval'240' hour from dual

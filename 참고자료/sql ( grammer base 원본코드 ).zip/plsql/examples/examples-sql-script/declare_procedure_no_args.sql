declare
    procedure proc;
    var number;
begin
    null;
end;
/

create or replace package pkg is
    procedure proc;
    var number;
end pkg;
/

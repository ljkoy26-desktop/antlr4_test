declare
    pragma autonomous_transaction;
begin
    commit;
end;
/

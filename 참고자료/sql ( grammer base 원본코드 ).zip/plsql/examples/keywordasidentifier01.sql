select timestamp, avg, cume_dist from nulls

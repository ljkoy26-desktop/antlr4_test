DROP INDEXTYPE position_indextype FORCE;
DROP INDEXTYPE position_indextype;
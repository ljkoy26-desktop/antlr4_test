select r.*
from t as r
where 11 + 2 * 3 = c and t = 2 or u = 3
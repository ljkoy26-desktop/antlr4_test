#begin
select 1+2*3-4;
select 1+9/3-2;
select 2+9%2-1；
#end
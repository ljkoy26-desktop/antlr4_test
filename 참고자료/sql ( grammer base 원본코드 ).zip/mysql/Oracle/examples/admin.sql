-- https://dev.mysql.com/doc/refman/8.0/en/set-statement.html
SET GLOBAL v1=1;
SET @@global.v2=2;
SET LOCAL v1=1;
SET @@local.v2=2;
SET SESSION v1=1;
SET @@session.v2=2;
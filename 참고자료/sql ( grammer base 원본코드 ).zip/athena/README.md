# Antlr grammar for AWS Athena

https://docs.aws.amazon.com/athena/latest/ug/ddl-sql-reference.html

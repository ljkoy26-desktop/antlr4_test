select 1 as c
from t
where c=1
group by d
order by e

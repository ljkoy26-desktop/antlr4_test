insert into t select 1 as c

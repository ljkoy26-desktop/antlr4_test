insert into t values(1,2),(3,4)

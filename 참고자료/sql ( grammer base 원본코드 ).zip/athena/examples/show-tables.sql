show tables in db

set deferred_prepare;
set deferred_prepare enabled;
set deferred_prepare DISABLED;

DROP USER bill;

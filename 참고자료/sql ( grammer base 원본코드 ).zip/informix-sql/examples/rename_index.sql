--rename index comments
RENAME INDEX index1001 TO idx1;
RENAME INDEX jmm.index1001 TO idx1;
DROP ROLE engineer;

DROP ROLE IF EXISTS engineer;

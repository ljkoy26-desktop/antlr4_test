--close stmt
CLOSE stmt1;

--database stmt
DATABASE stores_demo;

--colse database
CLOSE DATABASE;
DROP DATABASE stores_demo;
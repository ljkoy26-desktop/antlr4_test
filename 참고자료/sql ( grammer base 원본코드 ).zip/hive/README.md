# HIVE grammar for ANTLR4

An ANTLR4 grammars for HIVE based on versions 3.1.2 and 2.3.8 of official HIVE grammar.
The vast majority of grammar come from the official HIVE grammar of Apache HIVE.

## Resources:

* https://mvnrepository.com/artifact/org.apache.hive/hive-exec
* https://cwiki.apache.org/confluence/display/Hive/LanguageManual

# ANTLR4 grammar for Apache Hive version 4

https://github.com/apache/hive/tree/master/parser/src/java/org/apache/hadoop/hive/ql/parse

# MariaDB grammar

An ANTLR4 grammar for MariaDB based on version 10.0 and 10.2 of https://mariadb.org/documentation/.

show catalogs like '';
show connections;
show databases;
-- show functions;
show shares;
show tables;
show views;
show volumes;

describe database obj;
describe table obj;
describe schema obj;
describe catalog c;
describe volume v;

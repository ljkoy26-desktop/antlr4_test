select 1 as c;
select 1=1 as c;
select * from t;
select * from t where c=1 or d=1;
select * from t where c=1 group by all;
select * from t where c=1 group by all limit 10;
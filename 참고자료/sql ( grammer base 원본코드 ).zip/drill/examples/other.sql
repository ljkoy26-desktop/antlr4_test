show files in dfs.CSV;
analyze table t2 compute statistics;
refresh table metadata t1;
ALTER SYSTEM RESET `planner.add_producer_consumer`;
describe schema dfs;
describe ( select 1);

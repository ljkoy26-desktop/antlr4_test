
// Generated from MySQLParser.g4 by ANTLR 4.13.2


#include "MySQLParserVisitor.h"


using namespace antlrcpptest;


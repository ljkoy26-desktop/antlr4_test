#include "MySQLParserBase.h"

namespace antlrcpptest {

    MySQLParserBase::MySQLParserBase(antlr4::TokenStream* input) : antlr4::Parser(input)
    {
        serverVersion = 80200; // �⺻ ���� ����
    }

    bool MySQLParserBase::isSqlModeActive(SqlMode mode) {
        return sqlModes.count(mode) > 0;
    }

    // �ļ� ���� �Լ� (�ϴ� �׻� true/false �����ϴ� ������� ����)
    bool MySQLParserBase::isSelectStatementWithInto() { return false; }
    bool MySQLParserBase::isStoredRoutineBody() { return false; }

    // ���� üũ �Լ� ����
    bool MySQLParserBase::isServerVersionGe80011() { return serverVersion >= 80011; }
    bool MySQLParserBase::isServerVersionGe80013() { return serverVersion >= 80013; }
    bool MySQLParserBase::isServerVersionLt80014() { return serverVersion < 80014; }
    bool MySQLParserBase::isServerVersionGe80014() { return serverVersion >= 80014; }
    bool MySQLParserBase::isServerVersionGe80016() { return serverVersion >= 80016; }
    bool MySQLParserBase::isServerVersionGe80017() { return serverVersion >= 80017; }
    bool MySQLParserBase::isServerVersionGe80018() { return serverVersion >= 80018; }
    bool MySQLParserBase::isServerVersionGe80019() { return serverVersion >= 80019; }
    bool MySQLParserBase::isServerVersionLt80021() { return serverVersion < 80021; }
    bool MySQLParserBase::isServerVersionGe80021() { return serverVersion >= 80021; }
    bool MySQLParserBase::isServerVersionLt80022() { return serverVersion < 80022; }
    bool MySQLParserBase::isServerVersionGe80022() { return serverVersion >= 80022; }
    bool MySQLParserBase::isServerVersionLt80023() { return serverVersion < 80023; }
    bool MySQLParserBase::isServerVersionGe80023() { return serverVersion >= 80023; }
    bool MySQLParserBase::isServerVersionLt80024() { return serverVersion < 80024; }
    bool MySQLParserBase::isServerVersionGe80024() { return serverVersion >= 80024; }
    bool MySQLParserBase::isServerVersionLt80025() { return serverVersion < 80025; }
    bool MySQLParserBase::isServerVersionGe80025() { return serverVersion >= 80025; }
    bool MySQLParserBase::isServerVersionGe80027() { return serverVersion >= 80027; }
    bool MySQLParserBase::isServerVersionLt80031() { return serverVersion < 80031; }
    bool MySQLParserBase::isServerVersionGe80031() { return serverVersion >= 80031; }
    bool MySQLParserBase::isServerVersionGe80032() { return serverVersion >= 80032; }
    bool MySQLParserBase::isServerVersionGe80100() { return serverVersion >= 80100; }
    bool MySQLParserBase::isServerVersionGe80200() { return serverVersion >= 80200; }
    bool MySQLParserBase::isServerVersionLt80011() { return serverVersion < 80011; }
    bool MySQLParserBase::isServerVersionLt80012() { return serverVersion < 80012; }
    bool MySQLParserBase::isServerVersionLt80016() { return serverVersion < 80016; }
    bool MySQLParserBase::isServerVersionGe80004() { return serverVersion >= 80004; }


    bool MySQLParserBase::isServerVersionLt80017() {        return serverVersion < 80017;    }

    bool MySQLParserBase::isPureIdentifier() {
        // ���� ����: ���� ��ū�� ������ �ĺ���(ID)���� Ȯ���ؾ� ��.
        // �ϴ� ���� ����� ���� �⺻�� ��ȯ (�Ľ� ������ ���� true/false ���� �ʿ��� �� ����)
        return true;
    }

    bool MySQLParserBase::isTextStringLiteral() {
        // ���� ����: ���� ��ū�� �ؽ�Ʈ ���ڿ����� Ȯ���ؾ� ��.
        return true;
    }

}
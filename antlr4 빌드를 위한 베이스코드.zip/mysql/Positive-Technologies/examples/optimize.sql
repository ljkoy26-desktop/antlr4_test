#begin
OPTIMIZE TABLE t1;
OPTIMIZE TABLE t1, t2;
OPTIMIZE TABLES t1;
OPTIMIZE TABLES t1, t2;
optimize local table t1;
#end

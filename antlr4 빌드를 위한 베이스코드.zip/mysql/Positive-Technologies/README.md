# Positive Technologies MySQL grammar

An ANTLR4 grammar for MySQL based on version 5.6 , 5.7 and 8.0 of
[http://dev.mysql.com/doc/refman/5.6/en/](http://dev.mysql.com/doc/refman/5.6/en/).
[http://dev.mysql.com/doc/refman/5.7/en/](http://dev.mysql.com/doc/refman/5.7/en/).
[http://dev.mysql.com/doc/refman/8.0/en/](http://dev.mysql.com/doc/refman/8.0/en/).

> **This grammar will be removed around end of June 2025.** Pull requests are still possible and the grammar will be tested and updated until the removal date.

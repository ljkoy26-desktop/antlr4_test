###https://dev.mysql.com/doc/refman/8.0/en/table.html
#begin
TABLE t;
#end

#begin
TABLE t LIMIT 3;
#end

#begin
TABLE t ORDER BY b LIMIT 3;
#end




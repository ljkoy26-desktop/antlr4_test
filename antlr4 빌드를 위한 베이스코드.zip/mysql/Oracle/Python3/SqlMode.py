class SqlMode:
    NoMode = 0
    AnsiQuotes = 1
    HighNotPrecedence = 2
    PipesAsConcat = 3
    IgnoreSpace = 4
    NoBackslashEscapes = 5


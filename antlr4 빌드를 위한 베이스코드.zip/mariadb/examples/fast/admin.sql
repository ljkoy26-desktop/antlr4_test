--- https://mariadb.com/kb/en/set/
SET GLOBAL v1=1;
SET @@global.v2=2;
SET SESSION v1=1;
SET @@session.v2=2;
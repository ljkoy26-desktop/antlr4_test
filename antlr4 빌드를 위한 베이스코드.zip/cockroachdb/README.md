# An ANTLR4 grammar for Cockroach Database

https://www.cockroachlabs.com/docs/stable/sql-grammar

https://github.com/cockroachdb/cockroachdb-parser/blob/main/pkg/sql/scanner/scan.go
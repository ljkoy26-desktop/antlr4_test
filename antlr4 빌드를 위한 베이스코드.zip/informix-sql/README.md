# Informix database sql grammar for ANTLR4

An ANTLR4 grammar for Informix database.

See as https://www.ibm.com/docs/en/informix-servers/14.10?topic=programming-guide-sql-syntax.
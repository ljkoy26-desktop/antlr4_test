DROP INDEX index_user_id;

DROP INDEX IF EXISTS index_user_id;

DROP INDEX IF EXISTS index_user_id ONLINE;

DROP INDEX IF EXISTS owner.index_user_id ONLINE;

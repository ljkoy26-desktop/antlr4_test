RENAME SECURITY POLICY best TO honesty;
RENAME SECURITY LABEL honesty.opaque TO transparent;
RENAME SECURITY LABEL COMPONENT architect TO accountant;
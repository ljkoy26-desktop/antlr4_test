DROP DATABASE stores_demo;
DROP DATABASE IF EXISTS stores_demo;

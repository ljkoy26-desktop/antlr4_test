DROP SYNONYM nj_cust;
DROP SYNONYM cathyg.nj_cust;
DROP SYNONYM IF EXISTS cathyg.nj_cust;
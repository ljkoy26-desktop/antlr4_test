update t set c = 1 where d = 1;
delete from t where c = 1;
insert into t (a,b) values(1,2);
insert into t (a,b) values(1,2),(3,4);

create derby aggregate da FOR integer returns integer external name  'foo.bar.A';
create role r1;
create schema s1;
create schema s1 authorization u1;
create type t1 external name 'foo.bar.A' language java ;

select 1 from t;
select 1 as c from t;
select 1+1 as c from t;
select 1=1 and true as c from t;
select 1 from t where c = 1 order by d;
select * from t;
select a.* from t as a;

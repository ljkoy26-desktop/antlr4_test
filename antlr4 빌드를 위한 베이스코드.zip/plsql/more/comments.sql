-- com1
select * /*
com2 */
from dual; -- com3

Rem  Copyright (c) All Rights Reserved.

prompt . ## Hello world
alter synonym emp compile;
alter public synonym emp compile;
alter public synonym emp noneditionable;
alter public synonym sch.emp editionable;

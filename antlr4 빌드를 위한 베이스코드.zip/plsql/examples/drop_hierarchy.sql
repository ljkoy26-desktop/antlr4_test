DROP HIERARCHY product_hier;

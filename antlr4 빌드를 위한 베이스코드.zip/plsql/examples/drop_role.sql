drop role TEST_ROLE_AAA;

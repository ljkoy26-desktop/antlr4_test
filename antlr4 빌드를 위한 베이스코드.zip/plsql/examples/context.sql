CREATE CONTEXT hr_context USING emp_mgmt;



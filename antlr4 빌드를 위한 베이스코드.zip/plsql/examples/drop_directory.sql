DROP DIRECTORY bfile_dir;

select 'A' | | 'B'  from dual;

select a ä, b Ḅ from dual;

CREATE OR REPLACE PACKAGE ACCESS_SECURITY AS
-- omitted
END;
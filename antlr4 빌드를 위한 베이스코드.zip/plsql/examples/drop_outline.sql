DROP OUTLINE salaries;

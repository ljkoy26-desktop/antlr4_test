ALTER ATTRIBUTE DIMENSION product_attr_dim RENAME TO my_product_attr_dim;

ALTER HIERARCHY product_hier RENAME TO myproduct_hier;

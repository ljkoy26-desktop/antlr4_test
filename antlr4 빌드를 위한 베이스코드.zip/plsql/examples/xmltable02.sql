select xmlelement("other_attrs", xmlelement("parsing_user_id", parsing_user_id)).getClobVal() other
from f

DROP RESTORE POINT good_data;
DROP RESTORE POINT rp for pluggable database pdb;

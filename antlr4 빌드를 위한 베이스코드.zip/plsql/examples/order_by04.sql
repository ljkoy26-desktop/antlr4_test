select * from dual order by a nulls first,  b nulls last, substr(c, 1) collate generic_m

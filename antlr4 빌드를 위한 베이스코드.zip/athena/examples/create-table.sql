create table t as select 1 as c

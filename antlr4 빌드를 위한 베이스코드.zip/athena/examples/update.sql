update t set c = 1 where d = 1;

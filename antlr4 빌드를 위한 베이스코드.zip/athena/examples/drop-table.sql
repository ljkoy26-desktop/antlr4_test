drop table t1

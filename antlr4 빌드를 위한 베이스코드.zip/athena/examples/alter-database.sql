alter database db set dbproperties ('p1' = 'v1')
